<?php 
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id']) && $_SESSION['role'] == "utilisateur") {
    include "db-connexion.php";
    include "app/Model/User.php";
    $user = get_user_by_id($conn, $_SESSION['id']);
    
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Modifier mon profil</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body>
	<input type="checkbox" id="checkbox">
	<?php include "inc/header.php" ?>
	<div class="body">
		<?php include "inc/nav.php" ?>
		<section class="section-1">
			<h4 class="title">Modifier mon profil <br><a href="profile.php">Afficher mon profil</a></h4>
         <form class="form-1"
			      method="POST"
			      action="app/update-profile.php">
			      <?php if (isset($_GET['error'])) {?>
      	  	<div class="danger" role="alert">
			  <?php echo stripcslashes($_GET['error']); ?>
			</div>
      	  <?php } ?>

      	  <?php if (isset($_GET['success'])) {?>
      	  	<div class="success" role="alert">
			  <?php echo stripcslashes($_GET['success']); ?>
			</div>
      	  <?php } ?>
				<div class="input-holder">
					<lable>Email</lable>
					<input type="text" name="email" class="input-1" placeholder="Saisissez ici." value="<?=$user['email']?>"><br>
				</div>

				<div class="input-holder">
					<lable>Ancien mot de passe</lable>
					<input type="text" value="••••••••" name="password" class="input-1" placeholder="••••••••"><br>
				</div>
				<div class="input-holder">
					<lable>Nouveau mot de passe</lable>
					<input type="text" name="new_password" class="input-1" placeholder="••••••••"><br>
				</div>
				<div class="input-holder">
					<lable>Confirmer le nouveau mot de passe</lable>
					<input type="text" name="confirm_password" class="input-1" placeholder="••••••••"><br>
				</div>

				<button class="edit-btn">Modifier</button>
			</form>

		</section>
	</div>

<script type="text/javascript">
	var active = document.querySelector("#navList li:nth-child(3)");
	active.classList.add("active");
</script>
</body>
</html>
<?php }else{
   $em = "Première connexion";
   header("Location: login.php?error=$em");
   exit();
}
 ?>