-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 28 août 2025 à 17:41
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `archivage_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `nom_fichier` varchar(255) NOT NULL,
  `chemin_fichier` varchar(255) NOT NULL,
  `date_creation` datetime NOT NULL DEFAULT current_timestamp(),
  `id_utilisateur_ajout` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `documents`
--

INSERT INTO `documents` (`id`, `titre`, `type`, `nom_fichier`, `chemin_fichier`, `date_creation`, `id_utilisateur_ajout`) VALUES
(1, 'Document de test 1', 'decrets', 'document_test_1.pdf', 'documents/document_test_1.pdf', '2025-08-22 15:58:51', NULL),
(2, 'Document de test 2', 'resolutions', 'document_test_2.pdf', 'documents/document_test_2.pdf', '2025-08-22 15:58:51', NULL),
(3, 'Document de test 3', 'decisions', 'document_test_3.pdf', 'documents/document_test_3.pdf', '2025-08-22 15:58:51', NULL),
(4, 'Document de test 4', 'arretes', 'document_test_4.pdf', 'documents/document_test_4.pdf', '2025-08-22 15:58:51', NULL),
(5, 'Document de test 5', 'lois', 'document_test_5.pdf', 'documents/document_test_5.pdf', '2025-08-22 15:58:51', NULL),
(6, 'Document de test 6', 'decrets', 'document_test_6.pdf', 'documents/document_test_6.pdf', '2025-08-22 15:58:51', NULL),
(7, 'Document de test 7', 'notes', 'document_test_7.pdf', 'documents/document_test_7.pdf', '2025-08-22 15:58:51', NULL),
(8, 'Document de test 8', 'decrets', 'document_test_8.pdf', 'documents/document_test_8.pdf', '2025-08-22 15:58:51', NULL),
(9, 'Document de test 9', 'arretes', 'document_test_9.pdf', 'documents/document_test_9.pdf', '2025-08-22 15:58:51', NULL),
(10, 'Document de test 10', 'lois', 'document_test_10.pdf', 'documents/document_test_10.pdf', '2025-08-22 15:58:51', NULL),
(11, 'Document de test 11', 'resolutions', 'document_test_11.pdf', 'documents/document_test_11.pdf', '2025-08-22 15:58:51', NULL),
(12, 'Document de test 12', 'arretes', 'document_test_12.pdf', 'documents/document_test_12.pdf', '2025-08-22 15:58:51', NULL),
(13, 'Document de test 13', 'decrets', 'document_test_13.pdf', 'documents/document_test_13.pdf', '2025-08-22 15:58:51', NULL),
(14, 'Document de test 14', 'notes', 'document_test_14.pdf', 'documents/document_test_14.pdf', '2025-08-22 15:58:51', NULL),
(15, 'Document de test 15', 'decisions', 'document_test_15.pdf', 'documents/document_test_15.pdf', '2025-08-22 15:58:51', NULL),
(16, 'Document de test 16', 'resolutions', 'document_test_16.pdf', 'documents/document_test_16.pdf', '2025-08-22 15:58:51', NULL),
(17, 'Document de test 17', 'notes', 'document_test_17.pdf', 'documents/document_test_17.pdf', '2025-08-22 15:58:51', NULL),
(18, 'Document de test 18', 'arretes', 'document_test_18.pdf', 'documents/document_test_18.pdf', '2025-08-22 15:58:51', NULL),
(19, 'Document de test 19', 'decrets', 'document_test_19.pdf', 'documents/document_test_19.pdf', '2025-08-22 15:58:51', NULL),
(20, 'Document de test 20', 'lois', 'document_test_20.pdf', 'documents/document_test_20.pdf', '2025-08-22 15:58:51', NULL),
(21, 'Document de test 21', 'decisions', 'document_test_21.pdf', 'documents/document_test_21.pdf', '2025-08-22 15:58:51', NULL),
(22, 'Document de test 22', 'notes', 'document_test_22.pdf', 'documents/document_test_22.pdf', '2025-08-22 15:58:51', NULL),
(23, 'Document de test 23', 'lois', 'document_test_23.pdf', 'documents/document_test_23.pdf', '2025-08-22 15:58:51', NULL),
(24, 'Document de test 24', 'decrets', 'document_test_24.pdf', 'documents/document_test_24.pdf', '2025-08-22 15:58:51', NULL),
(25, 'Document de test 25', 'arretes', 'document_test_25.pdf', 'documents/document_test_25.pdf', '2025-08-22 15:58:51', NULL),
(26, 'Document de test 26', 'resolutions', 'document_test_26.pdf', 'documents/document_test_26.pdf', '2025-08-22 15:58:51', NULL),
(27, 'Document de test 27', 'decisions', 'document_test_27.pdf', 'documents/document_test_27.pdf', '2025-08-22 15:58:51', NULL),
(28, 'Document de test 28', 'notes', 'document_test_28.pdf', 'documents/document_test_28.pdf', '2025-08-22 15:58:51', NULL),
(29, 'Document de test 29', 'lois', 'document_test_29.pdf', 'documents/document_test_29.pdf', '2025-08-22 15:58:51', NULL),
(30, 'Document de test 30', 'decrets', 'document_test_30.pdf', 'documents/document_test_30.pdf', '2025-08-22 15:58:51', NULL),
(31, 'Document de test 31', 'resolutions', 'document_test_31.pdf', 'documents/document_test_31.pdf', '2025-08-22 15:58:51', NULL),
(32, 'Document de test 32', 'arretes', 'document_test_32.pdf', 'documents/document_test_32.pdf', '2025-08-22 15:58:51', NULL),
(33, 'Document de test 33', 'decisions', 'document_test_33.pdf', 'documents/document_test_33.pdf', '2025-08-22 15:58:51', NULL),
(34, 'Document de test 34', 'notes', 'document_test_34.pdf', 'documents/document_test_34.pdf', '2025-08-22 15:58:51', NULL),
(35, 'Document de test 35', 'lois', 'document_test_35.pdf', 'documents/document_test_35.pdf', '2025-08-22 15:58:51', NULL),
(36, 'Document de test 36', 'decrets', 'document_test_36.pdf', 'documents/document_test_36.pdf', '2025-08-22 15:58:51', NULL),
(37, 'Document de test 37', 'resolutions', 'document_test_37.pdf', 'documents/document_test_37.pdf', '2025-08-22 15:58:51', NULL),
(38, 'Document de test 38', 'arretes', 'document_test_38.pdf', 'documents/document_test_38.pdf', '2025-08-22 15:58:51', NULL),
(39, 'Document de test 39', 'decisions', 'document_test_39.pdf', 'documents/document_test_39.pdf', '2025-08-22 15:58:51', NULL),
(40, 'Document de test 40', 'notes', 'document_test_40.pdf', 'documents/document_test_40.pdf', '2025-08-22 15:58:51', NULL),
(41, 'Document de test 41', 'lois', 'document_test_41.pdf', 'documents/document_test_41.pdf', '2025-08-22 15:58:51', NULL),
(42, 'Document de test 42', 'decrets', 'document_test_42.pdf', 'documents/document_test_42.pdf', '2025-08-22 15:58:51', NULL),
(43, 'Document de test 43', 'resolutions', 'document_test_43.pdf', 'documents/document_test_43.pdf', '2025-08-22 15:58:51', NULL),
(44, 'Document de test 44', 'arretes', 'document_test_44.pdf', 'documents/document_test_44.pdf', '2025-08-22 15:58:51', NULL),
(45, 'Document de test 45', 'decisions', 'document_test_45.pdf', 'documents/document_test_45.pdf', '2025-08-22 15:58:51', NULL),
(46, 'Document de test 46', 'notes', 'document_test_46.pdf', 'documents/document_test_46.pdf', '2025-08-22 15:58:51', NULL),
(47, 'Document de test 47', 'lois', 'document_test_47.pdf', 'documents/document_test_47.pdf', '2025-08-22 15:58:51', NULL),
(48, 'Document de test 48', 'decrets', 'document_test_48.pdf', 'documents/document_test_48.pdf', '2025-08-22 15:58:51', NULL),
(49, 'Document de test 49', 'resolutions', 'document_test_49.pdf', 'documents/document_test_49.pdf', '2025-08-22 15:58:51', NULL),
(50, 'Document de test 50', 'arretes', 'document_test_50.pdf', 'documents/document_test_50.pdf', '2025-08-22 15:58:51', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('administrateur','agent','utilisateur') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `email`, `username`, `password`, `role`) VALUES
(1, 'admin@example.com', 'admin', 'admin123', 'administrateur'),
(2, 'agent@example.com', 'agent', 'agent123', 'agent'),
(3, 'user@example.com', 'user', 'user123', 'utilisateur'),
(4, 'k2m@rpi.com', 'k2m', 'k2m12341024', 'administrateur');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_utilisateur_ajout` (`id_utilisateur_ajout`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`id_utilisateur_ajout`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
