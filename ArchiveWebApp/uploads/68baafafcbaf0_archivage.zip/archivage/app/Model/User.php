<?php

function get_all_users($conn){ //ici on cree une fonction qui liste tous les utilisateurs
	$sql = "SELECT * FROM utilisateurs WHERE role =? "; //NB: utilisateur (sans "s") designe le role et utilisateurs (avec "s") designe la table dans la BD.
	$stmt = $conn->prepare($sql);
	$stmt->execute(["utilisateur"]);

	if($stmt->rowCount() > 0){
		$utilisateurs = $stmt->fetchAll();
	}else $utilisateurs = 0;

	return $utilisateurs;
}


function insert_user($conn, $data){ //ici on cree la fonction qui va ajouter l'utilisateur.
	$sql = "INSERT INTO utilisateurs (email, username, password, role) VALUES(?,?,?, ?)";
	$stmt = $conn->prepare($sql);
	$stmt->execute($data);
}

function update_user($conn, $data){ // ici on cree la fonction qui va plutot modifier les infos d'un utilisateurs deja existant.
	$sql = "UPDATE utilisateurs SET email=?, username=?, password=?, role=? WHERE id=? AND role=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute($data);
}

function delete_user($conn, $data){ //ici on cree la fonction qui permet de supprimer un utilisateur existant.
	$sql = "DELETE FROM utilisateurs WHERE id=? AND role=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute($data);
}


function get_user_by_id($conn, $id){ //ici on cree la fonction qui va rechercher un utilisateur a partir de son id
	$sql = "SELECT * FROM utilisateurs WHERE id =? ";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$id]);

	if($stmt->rowCount() > 0){
		$utilisateurs = $stmt->fetch();
	}else $utilisateurs = 0;

	return $utilisateurs;
}

function update_profile($conn, $data){ //ici on cree une fonction qui permet de mettre a jour un profile.
	$sql = "UPDATE utilisateurs SET email=?,  password=? WHERE id=? ";
	$stmt = $conn->prepare($sql);
	$stmt->execute($data);
}

function count_users($conn){ //ici on cree la fonction qui affiche le nombre total d'utilisateurs
	$sql = "SELECT id FROM utilisateurs WHERE role='utilisateur'";
	$stmt = $conn->prepare($sql);
	$stmt->execute([]);

	return $stmt->rowCount();
}