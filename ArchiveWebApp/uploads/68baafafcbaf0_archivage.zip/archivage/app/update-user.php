<?php
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id'])) {

if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email']) && $_SESSION['role'] == 'admin') {
	include "../db-connexion.php";

    function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
	}

	$username = validate_input($_POST['username']);
	$password = validate_input($_POST['password']);
	$email = validate_input($_POST['email']);
	$id = validate_input($_POST['id']);


	if (empty($username)) {
		$em = "Le nom d'utilisateur est requis!";
        header("Location: ../edit-user.php?error=$em&id=$id");
        exit();
	}else if (empty($password)) {
		$em = "Le mot de passe est requis!";
        header("Location: ../edit-user.php?error=$em&id=$id");
        exit();
	}else if (empty($email)) {
		$em = "L'email est requis!";
        header("Location: ../edit-user.php?error=$em&id=$id");
        exit();
	}else {

        include "Model/User.php";
        $password = password_hash($password, PASSWORD_DEFAULT);

        $data = array($email, $username, $password, "utilisateur", $id, "utilisateur");
        update_user($conn, $data);

        $em = "Utilisateur crée avec succès!";
        header("Location: ../edit-user.php?success=$em&id=$id");
        exit();


	}
}else {
    $em = "Unknown error occurred";
    header("Location: ../edit-user.php?error=$em");
    exit();
}

}else{
    $em = "First login";
    header("Location: ../edit-user.php?error=$em");
    exit();
}