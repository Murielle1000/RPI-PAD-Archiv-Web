<?php
include ('../db-connexion.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT `password`, `role`, `id`, `username` FROM `utilisateurs` WHERE `email` = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch();
        $stored_password = $row['password'];
        $stored_role = $row['role'];
        $user_id = $row['id'];
        $stored_username = $row['username'];

        if ($password === $stored_password) {
            session_start();
            $_SESSION['user_id'] = $user_id;

            if ($stored_role == 'administrateur') {
                echo "
                <script>
                    alert('Connexion réussie!');
                    window.location.href = 'http://localhost/archivage/index.php';
                </script>
                ";
            } else if ($stored_role == 'utilisateur') {
                echo "
                <script>
                    alert('Connexion reussie!');
                    window.location.href = 'http://localhost/archivage/index.php';
                </script>
                ";
            }

        } else {
            echo "
            <script>
                alert('Echec de connexion, Mot de passe incorrect!');
                window.location.href = 'http://localhost/archivage/';
            </script>
            ";
        }

    } else {
        echo "
            <script>
                alert('Echec de connexion, Utilisateur inexistant!');
                window.location.href = 'http://localhost/archivage/';
            </script>
            ";
    }
}

?>