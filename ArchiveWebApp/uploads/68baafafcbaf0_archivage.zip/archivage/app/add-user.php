<?php
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id'])) {

if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email']) && $_SESSION['role'] == 'admin') {  //ici on verifie les informations du compte de celui qui veut ajouter l'utilisateur, si c'est un admin c'est ok on suit le processus
	include "../db-connexion.php";

    function validate_input($data) { //ici on ecrit la fonction qui permettra de valiser les donnees entrees par l'admin en fonction de la bd
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
	}

	$username = validate_input($_POST['username']);
	$password = validate_input($_POST['password']);
	$email = validate_input($_POST['email']);

	if (empty($username)) { //ici on verifie les champs a l'envoi du formulaire
		$em = "Le nom d'utilisateur est requis !";
		header("Location: ../add-user.php?error=$em");
		exit();
	}else if (empty($password)) {
		$em = "Il faut ajouter un mot de passe!";
		header("Location: ../add-user.php?error=$em");
		exit();
	}else if (empty($email)) {
		$em = "Il faut renseigner l'email!";
		header("Location: ../add-user.php?error=$em");
		exit();
	}else {

		include "Model/User.php";
		$password = password_hash($password, PASSWORD_DEFAULT);

		$data = array($email, $username, $password, "utilisateur");
		insert_user($conn, $data);

		$em = "Utilisateur créé avec succès!";
		header("Location: ../add-user.php?success=$em");
		exit();


	}
}else {
	$em = "Unknown error occurred";
	header("Location: ../add-user.php?error=$em");
	exit();
}

}else{
	$em = "First login";
	header("Location: ../add-user.php?error=$em");
	exit();
}